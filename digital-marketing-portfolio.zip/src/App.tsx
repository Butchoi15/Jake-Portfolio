import React from 'react';
import { ArrowRight, CheckCircle2, TrendingUp, Users } from 'lucide-react';

export default function App() {
  return (
    <div className="min-h-screen bg-white text-slate-900 font-sans selection:bg-blue-200">
      {/* Header */}
      <header className="max-w-7xl mx-auto px-6 py-8 flex justify-between items-center bg-white">
        <div className="text-2xl font-black tracking-tight text-blue-600">
          MyPortfolio.
        </div>
        <nav className="hidden md:flex gap-8 font-bold text-slate-600">
          <a href="#about" className="hover:text-blue-600 transition-colors">About Me</a>
          <a href="#skills" className="hover:text-blue-600 transition-colors">My Skills</a>
          <a href="#contact" className="hover:text-blue-600 transition-colors">Contact</a>
        </nav>
        <button className="bg-blue-600 text-white px-6 py-3 rounded-full font-bold hover:bg-blue-700 transition-colors">
          Hire Me
        </button>
      </header>

      <main className="bg-white">
        {/* Hero Section */}
        <section className="max-w-7xl mx-auto px-6 py-20 md:py-32 grid md:grid-cols-2 gap-12 items-center bg-white">
          <div className="space-y-8">
            <h1 className="text-5xl md:text-7xl font-black leading-[1.1] tracking-tight">
              I Make Your Website <span className="text-blue-600">Super Popular!</span>
            </h1>
            <p className="text-xl md:text-2xl text-slate-600 font-medium leading-relaxed max-w-lg">
              You built a great business. Now let's make sure people actually see it. I bring the traffic, handle the tech, and turn visitors into paying customers.
            </p>
            
            <div className="flex flex-wrap gap-4 pt-4">
              <button className="bg-blue-600 text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-blue-700 transition-transform hover:scale-105 flex items-center gap-2 shadow-lg shadow-blue-200">
                Let's Work Together <ArrowRight className="w-5 h-5" />
              </button>
            </div>

            <div className="flex gap-12 pt-12 border-t border-slate-100">
              <div>
                <div className="text-4xl font-black text-slate-900">4+</div>
                <div className="text-slate-500 font-bold mt-1">Years Experience</div>
              </div>
              <div>
                <div className="text-4xl font-black text-slate-900">100%</div>
                <div className="text-slate-500 font-bold mt-1">Ready to Help</div>
              </div>
            </div>
          </div>

          {/* Image Placeholder Area - Pure white, waiting for user's image */}
          <div className="relative h-[500px] flex items-center justify-center bg-white">
            <div className="text-center space-y-4 p-8 border-4 border-dashed border-slate-200 rounded-3xl w-full h-full flex flex-col items-center justify-center">
              <p className="text-slate-500 font-bold text-lg">Your Awesome Photo Goes Here!</p>
              <p className="text-slate-400 font-medium text-sm">Upload your image later.</p>
              {/* You can replace this whole div with your <img src="..." /> later! */}
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section id="skills" className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-6">
            <div className="max-w-2xl mb-16">
              <h2 className="text-4xl md:text-5xl font-black tracking-tight mb-6">
                My Two Superpowers 🦸‍♂️
              </h2>
              <p className="text-xl text-slate-600 font-medium leading-relaxed">
                I have two main jobs. I can help you with one, or both! Here is what I do in simple words.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {/* Service 1 */}
              <div className="bg-white p-10 rounded-3xl shadow-sm border border-slate-100 hover:shadow-xl transition-shadow">
                <div className="w-16 h-16 bg-blue-600 text-white rounded-2xl flex items-center justify-center mb-8 shadow-lg shadow-blue-200">
                  <TrendingUp className="w-8 h-8" />
                </div>
                <h3 className="text-3xl font-black mb-4">Digital Marketing</h3>
                <p className="text-lg text-slate-600 font-medium mb-8 leading-relaxed">
                  I know the secret tricks to make Google love your website. This means more people will find you when they search online!
                </p>
                <ul className="space-y-4">
                  <li className="flex items-center gap-3 text-lg font-bold text-slate-700">
                    <CheckCircle2 className="w-6 h-6 text-blue-600" /> SEO (Making Google happy)
                  </li>
                  <li className="flex items-center gap-3 text-lg font-bold text-slate-700">
                    <CheckCircle2 className="w-6 h-6 text-blue-600" /> Link Building (Connecting websites)
                  </li>
                  <li className="flex items-center gap-3 text-lg font-bold text-slate-700">
                    <CheckCircle2 className="w-6 h-6 text-blue-600" /> Affiliate Marketing (Selling smart)
                  </li>
                </ul>
              </div>

              {/* Service 2 */}
              <div className="bg-white p-10 rounded-3xl shadow-sm border border-slate-100 hover:shadow-xl transition-shadow">
                <div className="w-16 h-16 bg-purple-600 text-white rounded-2xl flex items-center justify-center mb-8 shadow-lg shadow-purple-200">
                  <Users className="w-8 h-8" />
                </div>
                <h3 className="text-3xl font-black mb-4">Virtual Assistant</h3>
                <p className="text-lg text-slate-600 font-medium mb-8 leading-relaxed">
                  Need help running your online store? I can be your right-hand helper. I organize things and talk to your customers.
                </p>
                <ul className="space-y-4">
                  <li className="flex items-center gap-3 text-lg font-bold text-slate-700">
                    <CheckCircle2 className="w-6 h-6 text-purple-600" /> eCommerce (Running your shop)
                  </li>
                  <li className="flex items-center gap-3 text-lg font-bold text-slate-700">
                    <CheckCircle2 className="w-6 h-6 text-purple-600" /> Lead Generation (Finding buyers)
                  </li>
                  <li className="flex items-center gap-3 text-lg font-bold text-slate-700">
                    <CheckCircle2 className="w-6 h-6 text-purple-600" /> Customer Service (Making people smile)
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Simple CTA Section */}
        <section id="contact" className="py-24 max-w-4xl mx-auto px-6 text-center bg-white">
          <h2 className="text-4xl md:text-6xl font-black tracking-tight mb-8">
            Ready to make things <span className="text-blue-600">easy?</span>
          </h2>
          <p className="text-xl text-slate-600 font-medium mb-10">
            Send me a message. We can talk about how I can help your business grow without the headache.
          </p>
          <button className="bg-slate-900 text-white px-10 py-5 rounded-full font-black text-xl hover:bg-blue-600 transition-colors shadow-xl shadow-slate-200">
            Send Me a Message 💌
          </button>
        </section>
      </main>
    </div>
  );
}
